import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)


# LOAD DATASET

DATASET_PATH = "C:/Users/rahul/Downloads/nutrition.csv"
df = pd.read_csv(DATASET_PATH, low_memory=False)

print("Original Dataset:")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

#  DATA CLEANING

# Select only adult obesity records
df = df[df["Question"] ==
        "Percent of adults aged 18 years and older who have obesity"]

# Select useful columns
df = df[[
    "YearStart",
    "LocationDesc",
    "StratificationCategory1",
    "Stratification1",
    "Data_Value"
]].copy()

# Convert obesity values into numbers
df["Data_Value"] = pd.to_numeric(
    df["Data_Value"], errors="coerce"
)

# Remove missing values
df = df.dropna()

# Remove duplicate records
df = df.drop_duplicates()

# Display cleaned data
print("\nCleaned Dataset:")
print(df.head())

print("\nMissing Values:")
print(df.isnull().sum())

print("\nFinal Dataset Shape:")
print(df.shape)

# Save cleaned dataset
df.to_csv("cleaned_nutrition_data.csv", index=False)


# EXPLORATORY DATA ANALYSIS (EDA)

print("\n EDA ")

# Basic statistical information
print("\nStatistical Summary:")
print(df["Data_Value"].describe())

# Calculate mean, median and standard deviation
print("\nMean:", df["Data_Value"].mean())
print("Median:", df["Data_Value"].median())
print("Standard Deviation:", df["Data_Value"].std())
print("Minimum:", df["Data_Value"].min())
print("Maximum:", df["Data_Value"].max())

# Average obesity prevalence by year
print("\nYear-wise Obesity Average:")
print(df.groupby("YearStart")["Data_Value"].mean())

# Average obesity prevalence by demographic group
print("\nDemographic Analysis:")
print(df.groupby("StratificationCategory1")["Data_Value"].mean())


# DATA VISUALIZATION

# 1. LINE CHART
total_data = df[
    df["StratificationCategory1"] == "Total"
]

if len(total_data) > 0:
    trend_data = total_data
else:
    trend_data = df

yearly_data = trend_data.groupby(
    "YearStart"
)["Data_Value"].mean()

plt.figure(figsize=(8, 5))

plt.plot(
    yearly_data.index,
    yearly_data.values,
    marker="o"
)

plt.title("Obesity Prevalence Over the Years")
plt.xlabel("Year")
plt.ylabel("Obesity Prevalence (%)")
plt.grid(True)

plt.show()

# 2. CORRELATION HEATMAP

correlation = df[[
    "YearStart",
    "Data_Value"
]].corr()

plt.figure(figsize=(6, 4))

sns.heatmap(
    correlation,
    annot=True,
    cmap="coolwarm"
)

plt.title("Correlation Heatmap")

plt.show()

# REGRESSION MODELS

# Select input and output columns
X = df[[
    "YearStart",
    "LocationDesc",
    "StratificationCategory1",
    "Stratification1"
]]

y = df["Data_Value"]

# Convert categorical columns into numerical columns
X = pd.get_dummies(X, drop_first=True)

# Split data into training and testing sets

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# OBJECTIVE 1: SIMPLE LINEAR REGRESSION
# To predict the level of obesity depending on the number of years
# and determine the trend in obesity levels.

simple_model = LinearRegression()

simple_model.fit(
    X_train[["YearStart"]],
    y_train
)

simple_pred = simple_model.predict(
    X_test[["YearStart"]]
)

plt.figure(figsize=(8, 5))

plt.scatter(
    y_test,
    simple_pred,
    alpha=0.5
)

plt.plot(
    [y_test.min(), y_test.max()],
    [y_test.min(), y_test.max()],
    linestyle="--"
)

plt.title("Simple Linear Regression: Actual vs Predicted")
plt.xlabel("Actual Obesity Prevalence (%)")
plt.ylabel("Predicted Obesity Prevalence (%)")
plt.grid(True)

plt.show()

print("MAE:", mean_absolute_error(y_test, simple_pred))

print("MSE:", mean_squared_error(y_test, simple_pred))

print("RMSE:", np.sqrt(mean_squared_error(y_test, simple_pred)))

print("R2 Score:", r2_score(y_test, simple_pred))

# OBJECTIVE 2: MULTIPLE LINEAR REGRESSION
#To predict obesity based on multiple variables,
# including year, US state, and demographic groups.

multiple_model = LinearRegression()

multiple_model.fit(X_train, y_train)

multiple_pred = multiple_model.predict(X_test)

plt.figure(figsize=(8, 5))

plt.scatter(
    y_test,
    multiple_pred,
    alpha=0.5
)

plt.plot(
    [y_test.min(), y_test.max()],
    [y_test.min(), y_test.max()],
    color="red",
    linestyle="-"
)

plt.title("Multiple Linear Regression: Actual vs Predicted")
plt.xlabel("Actual Obesity Prevalence (%)")
plt.ylabel("Predicted Obesity Prevalence (%)")
plt.grid(True)

plt.show()

print("MAE:", mean_absolute_error(y_test, multiple_pred))

print("MSE:", mean_squared_error(y_test, multiple_pred))

print("RMSE:", np.sqrt(mean_squared_error(y_test, multiple_pred)))

print("R2 Score:", r2_score(y_test, multiple_pred))


#CLASSIFICATION DATA PREPARATION

# Create High and Lower obesity categories
# 30% or above = High (1)
# Below 30% = Lower (0)

df["Obesity_Category"] = np.where(
    df["Data_Value"] >= 30, 1, 0
)

# Select input and target columns
X_class = df[[
    "YearStart",
    "LocationDesc",
    "StratificationCategory1",
    "Stratification1"
]]

y_class = df["Obesity_Category"]

# Convert categorical columns into numerical columns
X_class = pd.get_dummies(X_class, drop_first=True)

# Split data into training and testing sets
X_train_c, X_test_c, y_train_c, y_test_c = train_test_split(
    X_class,
    y_class,
    test_size=0.2,
    random_state=42,
    stratify=y_class
)

# Scale the data for classification
scaler = StandardScaler()

X_train_c = scaler.fit_transform(X_train_c)
X_test_c = scaler.transform(X_test_c)


# OBJECTIVE 3: DECISION TREE CLASSIFICATION
# To categorize the prevalence of obesity into High and Lower
# using demographic and geographic data.

decision_model = DecisionTreeClassifier(
    max_depth=5,
    random_state=42
)

# Train the model
decision_model.fit(X_train_c, y_train_c)

# Make predictions
decision_pred = decision_model.predict(X_test_c)

plt.figure(figsize=(6, 4))

sns.heatmap(
    confusion_matrix(y_test_c, decision_pred),
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=["Lower", "High"],
    yticklabels=["Lower", "High"]
)

plt.title("Decision Tree - Confusion Matrix")
plt.xlabel("Predicted Category")
plt.ylabel("Actual Category")

plt.show()

# OBJECTIVE 4: LOGISTIC REGRESSION
# To forecast the likelihood that obesity rates will fall into the categories
# of High or Lower using demographic and geographical characteristics.

logistic_model = LogisticRegression(
    max_iter=1000
)

# Train the model
logistic_model.fit(X_train_c, y_train_c)

# Make predictions
logistic_pred = logistic_model.predict(X_test_c)

plt.figure(figsize=(6, 4))

sns.heatmap(
    confusion_matrix(y_test_c, logistic_pred),
    annot=True,
    fmt="d",
    cmap="Greens",
    xticklabels=["Lower", "High"],
    yticklabels=["Lower", "High"]
)

plt.title("Logistic Regression - Confusion Matrix")
plt.xlabel("Predicted Category")
plt.ylabel("Actual Category")

plt.show()

# OBJECTIVE 5: K-NEAREST NEIGHBORS (KNN)
#To categorize obesity prevalence through comparison of demographic 
# and geographic records with identical data.

knn_model = KNeighborsClassifier(
    n_neighbors=5
)

# Train the model
knn_model.fit(X_train_c, y_train_c)

# Make predictions
knn_pred = knn_model.predict(X_test_c)

plt.figure(figsize=(6, 4))

sns.heatmap(
    confusion_matrix(y_test_c, knn_pred),
    annot=True,
    fmt="d",
    cmap="Oranges",
    xticklabels=["Lower", "High"],
    yticklabels=["Lower", "High"]
)

plt.title("KNN - Confusion Matrix")
plt.xlabel("Predicted Category")
plt.ylabel("Actual Category")

plt.show()


# CLASSIFICATION MODEL EVALUATION

print("CLASSIFICATION RESULTS")

models_predictions = {
    "Decision Tree": decision_pred,
    "Logistic Regression": logistic_pred,
    "KNN": knn_pred
}

results = []

for name, pred in models_predictions.items():

    accuracy = accuracy_score(y_test_c, pred)

    precision = precision_score(
        y_test_c, pred, zero_division=0
    )

    recall = recall_score(
        y_test_c, pred, zero_division=0
    )

    f1 = f1_score(
        y_test_c, pred, zero_division=0
    )

    results.append([
        name, accuracy, precision, recall, f1
    ])

    print("\nModel:", name)
    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall:", recall)
    print("F1 Score:", f1)

    print("Confusion Matrix:")
    print(confusion_matrix(y_test_c, pred))


# MODEL COMPARISON

comparison = pd.DataFrame(
    results,
    columns=[
        "Model",
        "Accuracy",
        "Precision",
        "Recall",
        "F1 Score"
    ]
)
print("MODEL COMPARISON")
print(comparison)

# Save comparison results
comparison.to_csv(
    "classification_model_comparison.csv",
    index=False
)


# MODEL ACCURACY COMPARISON

plt.figure(figsize=(8, 5))

plt.bar(
    comparison["Model"],
    comparison["Accuracy"] * 100,
    color=["skyblue", "lightgreen", "orange"]
)

plt.title("Classification Models - Accuracy Comparison")
plt.xlabel("Classification Models")
plt.ylabel("Accuracy (%)")

plt.ylim(0, 100)
plt.grid(axis="y", linestyle="--", alpha=0.5)

plt.show()


# MODEL F1 SCORE COMPARISON

plt.figure(figsize=(8, 5))

plt.bar(
    comparison["Model"],
    comparison["F1 Score"] * 100,
    color=["Maroon", "Blue", "orange"]
)

plt.title("Classification Models - F1 Score Comparison")
plt.xlabel("Classification Models")
plt.ylabel("F1 Score (%)")

plt.ylim(0, 100)
plt.grid(axis="y", linestyle="--", alpha=0.5)

plt.show()